from setuptools import setup

setup(
    name = 'pydownloader',
    version = '0.1.0',
    description = 'Descargador de URLs con soporte (mega|mediafire|googledrive|youtube|directurl)',
    author = 'Obed Garcia Martinez',
    author_email = 'obysoftdev@gmail.com',
    packages = ['pydownloader','pydownloader.megacli'],
    install_requires=['bs4','requests','user_agent','mega.py','youtube_dl']
)